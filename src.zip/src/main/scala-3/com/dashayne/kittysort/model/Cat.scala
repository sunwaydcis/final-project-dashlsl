package com.dashayne.kittysort.model

import scalafx.beans.property.{StringProperty, IntegerProperty, ObjectProperty}
import java.time.LocalDate

class Cat ( catNameS : String, catBreedS : String):
  val catName = new StringProperty(catNameS)
  val catBreed = new StringProperty(catBreedS)


