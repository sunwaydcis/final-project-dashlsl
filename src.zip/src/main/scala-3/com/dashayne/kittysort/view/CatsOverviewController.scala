package com.dashayne.kittysort.view

import com.dashayne.kittysort.model.Cat
import com.dashayne.kittysort.MainApp
import javafx.fxml.FXML
import javafx.scene.control.{TableColumn, TableView}
import scalafx.Includes._

@FXML
class CatsOverviewController():

  @FXML
  private var catsTable: TableView[Cat] = null
  @FXML
  private var catNameColumn: TableColumn[Cat, String] = null
  @FXML
  private var catBreedColumn: TableColumn[Cat, String] = null

  def initialize() =
    catsTable.items = MainApp.catsData
    catNameColumn.cellValueFactory = {_.value.catName}
    catBreedColumn.cellValueFactory = {_.value.catBreed}


